# Prism Proximity Voice — prototype

This is an experimental proof-of-concept for Minecraft Bedrock Edition.

## What it does

- Minecraft runs the included behaviour pack.
- The pack publishes each player's X/Y/Z position and dimension to hidden scoreboards.
- The Windows world host connects Minecraft to the web service using `/wsserver`.
- Players open the web page, enter the same room code and their exact Minecraft Gamertag, then allow microphone access.
- The web page uses WebRTC for audio.
- Voice connections are created only when two players are within 32 blocks in the same dimension.
- Volume is full within 5 blocks and fades to zero at 32 blocks.

## Important limitations

1. This is a prototype, not a finished Marketplace product.
2. The normal Windows-hosted Bedrock client cannot let an addon open arbitrary network sockets. The host must run `/wsserver` once after launching Minecraft.
3. Cheats/admin permission are required for `/wsserver`.
4. iPad/phone microphone access needs an HTTPS page. Deploying the server to a host such as Render gives you HTTPS/WSS automatically.
5. Nintendo Switch cannot run this browser page inside Minecraft. A Switch player needs a phone/tablet beside the Switch for voice.
6. WebRTC using STUN works on many networks. Very restrictive NATs can require a TURN relay; no TURN service is included because that is difficult to guarantee free.
7. Bedrock's WebSocket command protocol is not a modern fully documented API. The server tries `querytarget` first and then falls back to the add-on's scoreboards. If a future Bedrock update changes command-response formatting, the bridge parser may need adjusting.

## Install the addon

1. Double-click `Prism_Proximity_Voice_Bridge.mcpack` on the Windows PC.
2. Edit your Minecraft world.
3. Behaviour Packs -> My Packs -> activate **Prism Proximity Voice Bridge**.
4. Turn **Cheats** on. The pack itself uses stable Script API features and does not need Beta APIs.

## Deploy the browser/bridge for free on Render

Upload this project to a Git repository, then create a Render Web Service using the included `render.yaml`, or manually set:

- Root directory: `server`
- Build command: `npm install`
- Start command: `npm start`
- Plan: Free

After deployment you will get an address similar to:

`https://YOUR-NAME.onrender.com`

Pick a room code, e.g. `FAMILY7`.

## Start a Minecraft session

On the Windows world host, join your world and run:

`/wsserver wss://YOUR-NAME.onrender.com/minecraft?room=FAMILY7`

If Minecraft rejects encrypted WebSockets, check Minecraft Settings for its WebSocket encryption setting.

Then everyone opens:

`https://YOUR-NAME.onrender.com`

They enter:
- Room code: `FAMILY7`
- Their exact Minecraft Gamertag

and tap **Join voice**.

### Device use

- Windows player: browser can run on the same PC.
- iPad player: Minecraft + browser page on iPad; browser may need to remain active enough for audio.
- Switch player: Minecraft on Switch + browser page on a phone/iPad.

## Testing

Start with two players standing next to each other. The browser should say "Linked to your Minecraft player" and show the other player in Nearby Players.

Walk more than 32 blocks apart. Their peer connection should close and audio should stop.

## Files

- `addon/Prism_Proximity_BP/` — source behaviour pack
- `server/server.js` — Minecraft WebSocket bridge + voice signalling
- `server/public/index.html` — browser microphone/WebRTC client
- `render.yaml` — free Render deployment definition
