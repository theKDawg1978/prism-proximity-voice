import express from "express";
import http from "http";
import crypto from "crypto";
import { WebSocketServer, WebSocket } from "ws";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 10000);

const app = express();
app.use(express.static(path.join(__dirname, "public")));
app.get("/health", (_req, res) => res.json({ ok: true }));

const server = http.createServer(app);
const minecraftWss = new WebSocketServer({ noServer: true });
const voiceWss = new WebSocketServer({ noServer: true });

const rooms = new Map();

function roomState(code) {
  const key = (code || "PRISM").toUpperCase().replace(/[^A-Z0-9_-]/g, "").slice(0, 20) || "PRISM";
  if (!rooms.has(key)) rooms.set(key, { minecraft: null, positions: new Map(), browsers: new Map(), poll: null });
  return [key, rooms.get(key)];
}

server.on("upgrade", (req, socket, head) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  if (url.pathname === "/minecraft") {
    minecraftWss.handleUpgrade(req, socket, head, ws => minecraftWss.emit("connection", ws, req));
  } else if (url.pathname === "/voice") {
    voiceWss.handleUpgrade(req, socket, head, ws => voiceWss.emit("connection", ws, req));
  } else {
    socket.destroy();
  }
});

function uuid() {
  return crypto.randomUUID();
}

const pending = new WeakMap();

function command(ws, commandLine, timeoutMs = 2500) {
  return new Promise((resolve, reject) => {
    if (ws.readyState !== WebSocket.OPEN) return reject(new Error("Minecraft socket not open"));
    const requestId = uuid();
    let map = pending.get(ws);
    if (!map) {
      map = new Map();
      pending.set(ws, map);
    }
    const timer = setTimeout(() => {
      map.delete(requestId);
      reject(new Error(`Timeout: ${commandLine}`));
    }, timeoutMs);
    map.set(requestId, { resolve, reject, timer, commandLine });

    ws.send(JSON.stringify({
      header: {
        version: 1,
        requestId,
        messageType: "commandRequest",
        messagePurpose: "commandRequest"
      },
      body: {
        version: 1,
        origin: { type: "player" },
        commandLine
      }
    }));
  });
}

function flattenStrings(value, out = []) {
  if (typeof value === "string") out.push(value);
  else if (Array.isArray(value)) value.forEach(v => flattenStrings(v, out));
  else if (value && typeof value === "object") Object.values(value).forEach(v => flattenStrings(v, out));
  return out;
}

function extractPlayersFromList(body) {
  if (Array.isArray(body?.playerNames)) return body.playerNames;
  if (typeof body?.players === "string") {
    return body.players.split(",").map(s => s.trim()).filter(Boolean);
  }
  if (Array.isArray(body?.players)) return body.players.map(String);
  const strings = flattenStrings(body);
  const candidate = strings.find(s => s.includes(",") && !s.includes("commands."));
  return candidate ? candidate.split(",").map(s => s.trim()).filter(Boolean) : [];
}

function parsePositionFromQueryTarget(body) {
  // querytarget implementations vary. Search recursively for records containing x/y/z + name.
  const found = [];
  const walk = (v) => {
    if (!v) return;
    if (Array.isArray(v)) return v.forEach(walk);
    if (typeof v !== "object") return;
    const loc = v.position || v.location;
    const name = v.name || v.playerName || v?.player?.name;
    if (name && loc && Number.isFinite(Number(loc.x)) && Number.isFinite(Number(loc.y)) && Number.isFinite(Number(loc.z))) {
      found.push({
        name: String(name),
        x: Number(loc.x), y: Number(loc.y), z: Number(loc.z),
        d: Number(v.dimension ?? v?.player?.dimension ?? 0)
      });
    }
    Object.values(v).forEach(walk);
  };
  walk(body);
  return found;
}

function parseScoreboard(body) {
  const text = flattenStrings(body).join("\n");
  const read = (id) => {
    const patterns = [
      new RegExp(`${id}\\D{0,40}(-?\\d+)`, "i"),
      new RegExp(`(-?\\d+)\\D{0,40}${id}`, "i")
    ];
    for (const p of patterns) {
      const m = text.match(p);
      if (m) return Number(m[1]);
    }
    return null;
  };
  const x = read("pvcX"), y = read("pvcY"), z = read("pvcZ"), d = read("pvcD");
  if ([x, y, z, d].some(v => v === null || !Number.isFinite(v))) return null;
  return { x: x / 10, y: y / 10, z: z / 10, d };
}

function safeTarget(name) {
  return `"${String(name).replace(/["\\]/g, "")}"`;
}

async function refreshPositions(ws, state) {
  // First try querytarget: some Bedrock websocket builds return structured transforms directly.
  try {
    const q = await command(ws, "querytarget @a", 1200);
    const direct = parsePositionFromQueryTarget(q);
    if (direct.length) {
      state.positions = new Map(direct.map(p => [p.name, p]));
      publishNeighbours(state);
      return;
    }
  } catch (_) {}

  // Stable fallback: addon publishes locations into hidden scoreboards.
  let players = [];
  try {
    const body = await command(ws, "list", 1200);
    players = extractPlayersFromList(body);
  } catch (_) {}

  if (!players.length) return;

  const updated = new Map();
  for (const name of players.slice(0, 16)) {
    try {
      const body = await command(ws, `scoreboard players list ${safeTarget(name)}`, 1200);
      const p = parseScoreboard(body);
      if (p) updated.set(name, { name, ...p });
    } catch (_) {}
  }

  if (updated.size) {
    state.positions = updated;
    publishNeighbours(state);
  }
}

function distance(a, b) {
  if (!a || !b || a.d !== b.d) return Infinity;
  return Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z);
}

function sendJSON(ws, obj) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
}

function publishNeighbours(state) {
  const MAX = 32;
  for (const [name, ws] of state.browsers) {
    const me = state.positions.get(name);
    const neighbours = [];
    if (me) {
      for (const [otherName] of state.browsers) {
        if (otherName === name) continue;
        const other = state.positions.get(otherName);
        const dist = distance(me, other);
        if (dist <= MAX) neighbours.push({ name: otherName, distance: Math.round(dist * 10) / 10 });
      }
    }
    sendJSON(ws, {
      type: "proximity",
      verified: Boolean(me),
      me: me || null,
      neighbours,
      onlineMinecraftPlayers: [...state.positions.keys()]
    });
  }
}

minecraftWss.on("connection", (ws, req) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const [room, state] = roomState(url.searchParams.get("room"));

  if (state.minecraft && state.minecraft.readyState === WebSocket.OPEN) {
    state.minecraft.close(4001, "Minecraft host replaced");
  }
  state.minecraft = ws;

  ws.on("message", raw => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return; }
    const reqId = msg?.header?.requestId;
    const purpose = msg?.header?.messagePurpose;
    if (reqId && purpose === "commandResponse") {
      const map = pending.get(ws);
      const item = map?.get(reqId);
      if (item) {
        clearTimeout(item.timer);
        map.delete(reqId);
        item.resolve(msg.body || {});
      }
    }
  });

  ws.on("close", () => {
    if (state.minecraft === ws) state.minecraft = null;
    if (state.poll) clearInterval(state.poll);
    state.poll = null;
    state.positions = new Map();
    publishNeighbours(state);
  });

  // Give the Bedrock client a moment before polling.
  setTimeout(() => refreshPositions(ws, state).catch(() => {}), 500);
  state.poll = setInterval(() => refreshPositions(ws, state).catch(() => {}), 750);

  console.log(`Minecraft connected to room ${room}`);
});

voiceWss.on("connection", (ws, req) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const [room, state] = roomState(url.searchParams.get("room"));
  let name = null;

  ws.on("message", raw => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return; }

    if (msg.type === "join") {
      const requested = String(msg.name || "").trim();
      if (!requested || requested.length > 40) return;
      name = requested;
      const old = state.browsers.get(name);
      if (old && old !== ws) old.close(4002, "Gamertag opened elsewhere");
      state.browsers.set(name, ws);
      sendJSON(ws, { type: "joined", room, name });
      publishNeighbours(state);
      return;
    }

    if (msg.type === "signal" && name) {
      const target = state.browsers.get(String(msg.to || ""));
      if (target) {
        sendJSON(target, { type: "signal", from: name, data: msg.data });
      }
    }
  });

  ws.on("close", () => {
    if (name && state.browsers.get(name) === ws) state.browsers.delete(name);
    publishNeighbours(state);
  });
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`Prism Proximity Voice listening on ${PORT}`);
});
