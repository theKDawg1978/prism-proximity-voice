import { world, system } from "@minecraft/server";

const OBJECTIVES = [
  ["pvcX", "Prism X"],
  ["pvcY", "Prism Y"],
  ["pvcZ", "Prism Z"],
  ["pvcD", "Prism Dimension"]
];

function ensureObjectives() {
  for (const [id, displayName] of OBJECTIVES) {
    if (!world.scoreboard.getObjective(id)) {
      try {
        world.scoreboard.addObjective(id, displayName);
      } catch (_) {}
    }
  }
}

function dimensionCode(id) {
  if (id === "minecraft:nether" || id === "nether") return 1;
  if (id === "minecraft:the_end" || id === "the_end") return 2;
  return 0;
}

system.run(() => {
  ensureObjectives();

  system.runInterval(() => {
    ensureObjectives();

    const ox = world.scoreboard.getObjective("pvcX");
    const oy = world.scoreboard.getObjective("pvcY");
    const oz = world.scoreboard.getObjective("pvcZ");
    const od = world.scoreboard.getObjective("pvcD");

    if (!ox || !oy || !oz || !od) return;

    for (const player of world.getAllPlayers()) {
      const identity = player.scoreboardIdentity;
      if (!identity) continue;

      const p = player.location;
      // x10 gives 0.1-block resolution while remaining well inside scoreboard integer range.
      ox.setScore(identity, Math.round(p.x * 10));
      oy.setScore(identity, Math.round(p.y * 10));
      oz.setScore(identity, Math.round(p.z * 10));
      od.setScore(identity, dimensionCode(player.dimension.id));
    }
  }, 5); // four updates per second
});
